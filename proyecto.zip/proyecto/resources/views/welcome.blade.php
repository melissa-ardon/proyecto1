@extends('layout.plantilla')
@section('contenido')
    Esta es la pagina principal

@endsection
